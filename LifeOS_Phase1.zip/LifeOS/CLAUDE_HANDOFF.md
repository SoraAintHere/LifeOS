# LifeOS — Claude Handoff

## Project purpose
LifeOS is a personal life-management application. The current build is an early application shell, not a finished product. Continue from the supplied files rather than starting over.

## Product modules planned
- Overview / Dashboard
- Calendar, events and prioritized reminders
- Tasks / To-do
- Finance tracker (manual balance, transactions, budgets and safe-spending estimates)
- Activity / steps
- Knowledge Hub / notes, tags and connections
- Goals / progress
- Reflection / journaling
- Future rule-based LifeOS Brain that cross-references modules, detects conflicts and suggests actions

## Decisions already made
- Responsive across mobile, tablet and desktop.
- Dark and light themes are equally important.
- Local-first storage, with architecture that can become cloud-ready later.
- Plain HTML, CSS and vanilla JavaScript for the initial implementation.
- IndexedDB is intended as the main data store; localStorage is for small preferences such as theme.
- Keep the project usable in Acode on Android. `index.html` is the entry point.
- No build step, bundler, npm, React, or ES modules for this stage.
- The user is a beginner and needs simple, explicit instructions when code changes are handed back.

## Current file structure
```text
LifeOS/
├── index.html
├── css/
│   ├── themes.css
│   ├── main.css
│   └── responsive.css
└── js/
    ├── app.js
    └── data/
        ├── database.js
        └── storage.js
```

## Current state
- The application shell has working navigation between placeholder modules.
- Dark/light theme toggle works and the selected theme is stored in localStorage.
- Dashboard is a static placeholder with overview cards.
- The responsive layout has a desktop sidebar and mobile bottom navigation.
- IndexedDB database and storage wrapper files have been drafted, but **database initialization and CRUD operations have not yet been successfully verified by the user**.
- `index.html` currently contains a temporary database connection alert test. Remove this temporary diagnostic only after replacing it with a proper initialization flow and verifying it works.
- Do not claim the database is verified until it has been tested in the actual app.

## Existing storage design
`database.js` creates an IndexedDB database named `LifeOS`, version 1, with these object stores:
- events
- tasks
- transactions
- notes
- goals
- activity
- reflections
- settings

Each store currently uses `id` as its keyPath.

`storage.js` exposes `window.LifeOSStorage` with:
- `add(store, data)`
- `put(store, data)`
- `get(store, id)`
- `getAll(store)`
- `delete(store, id)`
- `clear(store)`
- `count(store)`

It exposes `window.LifeOSDB` for database initialization and metadata.

## Important instructions
1. **Do not start over or replace the project architecture.**
2. Preserve the current working navigation and theme functionality.
3. Keep the current CSS theme variables and support both dark and light appearances.
4. Do not silently remove or rename existing files, global APIs, data stores, or public functions. If a change is necessary, explain why and update all dependent files consistently.
5. Do not introduce ES modules, npm, bundlers, build tools, or server dependencies. Use ordinary `<script src="..."></script>` tags in the correct dependency order.
6. Keep JavaScript modular using small IIFEs / namespaced globals where practical.
7. Separate application logic and data access from UI rendering so the UI can be redesigned without rewriting business logic.
8. Prioritize functional, accessible, responsive UI—not mock buttons or decorative controls. Every visible control should work or be clearly marked as not implemented.
9. Use localStorage only for small preferences. Use IndexedDB for user-created records.
10. Avoid destructive database changes. Never clear or overwrite user data during initialization or migrations.
11. Add robust error handling and visible, understandable feedback. Do not rely only on console logs.
12. Do not invent product requirements. Ask the user when a major product decision is unclear.
13. When returning code, provide complete replacement files with exact paths and explain the order to apply/test them. The user edits files on Android in Acode and runs `index.html`.

## Suggested next steps
1. Inspect the supplied files and explain the current architecture briefly.
2. Stabilize and test database initialization and CRUD operations first, without changing the visual design.
3. Remove the temporary alert diagnostic after a proper initialization state is implemented.
4. Add a small test workflow or internal self-test that writes, reads and deletes a clearly identified test record safely.
5. Once storage is verified, build the first complete module (suggested: Tasks or Calendar) and connect it to the dashboard.
6. Keep the visual system consistent and responsive.

## Design handoff
The user plans to have Claude take the lead on frontend design and visual implementation. Treat the supplied CSS as the current working baseline, not an untouchable final design. You may improve the visual design, but preserve its dark/light theme support, responsive behavior, existing navigation semantics, and all working functionality. Discuss major redesigns before removing established patterns.

## Communication style
The user prefers direct, casual explanations and needs beginner-friendly, step-by-step file instructions. Avoid dumping many unrelated changes at once. Explain which exact file to open, whether to replace all contents, and how to test it.
