(function () {
  "use strict";

  /*
    LifeOS startup flow:
      1. check every needed file loaded
      2. open the database
      3. only then start the app screen
    If something fails, a clear message is shown. Nothing is ever
    deleted or reset by this file.
  */

  const app = document.getElementById("app");

  const REQUIRED = [
    "LifeOSDB",
    "LifeOSStorage",
    "LifeOSSelfTest",
    "LifeOSStorageCheckUI",
    "LifeOSApp"
  ];

  const status = {
    state: "loading",   // loading | ready | error
    error: null,
    database: null
  };

  let slowTimer = null;

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function showLoading(message) {
    app.innerHTML = `
      <div class="loading" role="status">
        <h1>Life<span>OS</span></h1>
        <p>${escapeHtml(message)}</p>
      </div>
    `;
  }

  function showError(title, message, error) {
    const technical = error
      ? (error.name ? error.name + ": " : "") + (error.message || "")
      : "";

    app.innerHTML = `
      <div class="boot-screen boot-error" role="alert">
        <h1>Life<span>OS</span></h1>
        <h2>${escapeHtml(title)}</h2>
        <p>${escapeHtml(message)}</p>
        <p class="boot-reassure">
          LifeOS does not delete or reset your data when this happens.
        </p>
        <button class="button" data-boot-retry>Try again</button>
        ${technical ? `
          <details>
            <summary>Technical details</summary>
            <pre>${escapeHtml(technical)}</pre>
          </details>
        ` : ""}
      </div>
    `;
  }

  function missingParts() {
    return REQUIRED.filter(function (name) {
      return !window[name];
    });
  }

  function onOpened(db) {
    clearTimeout(slowTimer);

    status.state = "ready";
    status.error = null;
    status.database = {
      name: window.LifeOSDB.name,
      version: window.LifeOSDB.version,
      stores: window.LifeOSDB.stores.slice()
    };

    try {
      window.LifeOSApp.start();
    } catch (error) {
      status.state = "error";
      status.error = error;
      console.error(error);
      showError(
        "LifeOS could not start",
        "The database opened fine, but the screen failed to load.",
        error
      );
    }
  }

  function onFailed(error) {
    clearTimeout(slowTimer);

    status.state = "error";
    status.error = error;
    console.error(error);

    showError(
      "LifeOS could not open its storage",
      (error && error.message) || "The database did not open.",
      error
    );
  }

  function start() {
    clearTimeout(slowTimer);
    status.state = "loading";
    status.error = null;

    const missing = missingParts();

    if (missing.length > 0) {
      status.state = "error";
      showError(
        "Some LifeOS files did not load",
        "Missing: " + missing.join(", ") +
        ". Check the <script> lines in index.html and the file names and folders.",
        null
      );
      return Promise.resolve();
    }

    // Show the saved light/dark choice right away (no flash).
    window.LifeOSApp.applyTheme();

    showLoading("Initializing your workspace");

    slowTimer = setTimeout(function () {
      showLoading(
        "Still working… If this keeps happening, close other LifeOS tabs or windows and try again."
      );
    }, 8000);

    return window.LifeOSDB.open().then(onOpened, onFailed);
  }

  app.addEventListener("click", function (event) {
    if (event.target.closest("[data-boot-retry]")) {
      start();
    }
  });

  window.LifeOSBoot = {
    start: start,
    getStatus: function () {
      return {
        state: status.state,
        error: status.error,
        database: status.database
      };
    }
  };

  start();

})();
