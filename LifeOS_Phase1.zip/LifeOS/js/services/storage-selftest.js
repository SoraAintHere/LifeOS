(function () {
  "use strict";

  /*
    LifeOS storage self-test (logic only, no screen code).

    SAFETY:
    - Writes ONE clearly marked test record into the "settings"
      collection, then deletes that exact record.
    - Never calls clear(). Never touches any other record.
    - Counts every collection before and after, and checks that
      the numbers are identical.
    - The test record is removed even if a step fails.
    - run() never throws: it always returns a report.
  */

  const TEST_STORE = "settings";
  const TEST_PREFIX = "__selftest__";

  function describe(error) {
    if (!error) return "Unknown error";
    const name = error.name && error.name !== "Error" ? error.name + ": " : "";
    return name + (error.message || String(error));
  }

  function makeTestId() {
    return TEST_PREFIX + Date.now() + "-" +
      Math.random().toString(36).slice(2, 8);
  }

  function isLeftoverTestRecord(record) {
    return !!record &&
      record.isSelfTest === true &&
      typeof record.id === "string" &&
      record.id.indexOf(TEST_PREFIX) === 0;
  }

  async function countAll(storage, db) {
    const counts = {};
    for (const name of db.stores) {
      counts[name] = await storage.count(name);
    }
    return counts;
  }

  function sameCounts(a, b) {
    return Object.keys(a).every(function (key) {
      return a[key] === b[key];
    });
  }

  function total(counts) {
    return Object.keys(counts).reduce(function (sum, key) {
      return sum + counts[key];
    }, 0);
  }

  async function run() {
    const db = window.LifeOSDB;
    const storage = window.LifeOSStorage;
    const started = Date.now();
    const testId = makeTestId();

    const report = {
      ok: false,
      testId: testId,
      steps: [],
      cleanedUp: false,
      dataUntouched: null,
      ms: 0
    };

    let halted = false;
    let attemptedWrite = false;
    let countsBefore = null;

    async function step(name, fn, alwaysRun) {
      if (halted && !alwaysRun) {
        return false;
      }

      try {
        const detail = await fn();
        report.steps.push({ name: name, ok: true, detail: detail || "" });
        return true;
      } catch (error) {
        report.steps.push({ name: name, ok: false, detail: describe(error) });
        halted = true;
        return false;
      }
    }

    const record = {
      id: testId,
      isSelfTest: true,
      note: "LifeOS storage self-test record. Safe to delete.",
      value: "created",
      createdAt: new Date().toISOString()
    };

    try {
      await step("Open the database", async function () {
        await db.open();
        return db.name + ", version " + db.version;
      });

      await step("Remove leftover test records", async function () {
        const all = await storage.getAll(TEST_STORE);
        const leftovers = all.filter(isLeftoverTestRecord);

        for (const old of leftovers) {
          await storage.delete(TEST_STORE, old.id);
        }

        return leftovers.length === 0
          ? "None found"
          : "Removed " + leftovers.length + " from an earlier test";
      });

      await step("Count your existing records", async function () {
        countsBefore = await countAll(storage, db);
        return db.stores.length + " collections, " +
          total(countsBefore) + " records in total";
      });

      await step("Save the test record", async function () {
        attemptedWrite = true;
        await storage.add(TEST_STORE, record);
        return "Saved";
      });

      await step("Read it back", async function () {
        const saved = await storage.get(TEST_STORE, testId);
        if (!saved || saved.note !== record.note || saved.value !== "created") {
          throw new Error("The record that came back did not match what was saved.");
        }
        return "Matches what was saved";
      });

      await step("Update it", async function () {
        const saved = await storage.get(TEST_STORE, testId);
        await storage.put(TEST_STORE, Object.assign({}, saved, { value: "updated" }));
        const again = await storage.get(TEST_STORE, testId);
        if (!again || again.value !== "updated") {
          throw new Error("The update was not saved.");
        }
        return "Update saved";
      });

      await step("Check that add() cannot overwrite", async function () {
        let overwrote = false;

        try {
          await storage.add(TEST_STORE, Object.assign({}, record, { value: "overwritten" }));
          overwrote = true;
        } catch (ignore) {
          // Expected: the database refused the duplicate.
        }

        if (overwrote) {
          throw new Error("add() replaced an existing record. It must refuse.");
        }

        const still = await storage.get(TEST_STORE, testId);
        if (!still || still.value !== "updated") {
          throw new Error("The record changed after a refused add().");
        }

        return "Duplicate was refused, original kept";
      });

    } finally {

      // Cleanup ALWAYS runs, even after a failure above.
      if (attemptedWrite) {
        await step("Delete the test record", async function () {
          await storage.delete(TEST_STORE, testId);
          const gone = await storage.get(TEST_STORE, testId);
          if (gone !== undefined) {
            throw new Error("The test record is still there.");
          }
          report.cleanedUp = true;
          return "Removed";
        }, true);
      } else {
        report.cleanedUp = true; // nothing was written
      }

      if (countsBefore) {
        await step("Confirm your data was not touched", async function () {
          const countsAfter = await countAll(storage, db);
          report.dataUntouched = sameCounts(countsBefore, countsAfter);
          if (!report.dataUntouched) {
            throw new Error("Record counts changed during the test.");
          }
          return "Record counts are identical to before";
        }, true);
      }
    }

    report.ok =
      report.steps.length > 0 &&
      report.steps.every(function (s) { return s.ok; }) &&
      report.cleanedUp === true &&
      report.dataUntouched === true;

    report.ms = Date.now() - started;
    return report;
  }

  window.LifeOSSelfTest = {
    run: run
  };

})();
