(function () {
  "use strict";

  /*
    LifeOS database (IndexedDB)

    DATA SAFETY RULES for this file:
    1. Upgrades are ADDITIVE ONLY. They may create new collections
       (object stores) but must never delete, clear, or rewrite
       existing ones.
    2. If anything goes wrong during an upgrade, the upgrade is
       cancelled and the old data stays exactly as it was.
    3. If the saved data is NEWER than this code understands, we stop
       and explain, instead of touching anything.

    HOW TO ADD A NEW COLLECTION LATER:
      a) Add its name to STORES below.
      b) Raise DB_VERSION by 1 (for example 1 -> 2).
      c) Add a migration for that new version in MIGRATIONS.
  */

  const DB_NAME = "LifeOS";
  const DB_VERSION = 1;

  const STORES = [
    "events",
    "tasks",
    "transactions",
    "notes",
    "goals",
    "activity",
    "reflections",
    "settings"
  ];

  // Creates any collection that does not exist yet. Never removes anything.
  function createMissingStores(db) {
    STORES.forEach(function (name) {
      if (!db.objectStoreNames.contains(name)) {
        db.createObjectStore(name, { keyPath: "id" });
      }
    });
  }

  // One entry per database version. Each one must be additive only.
  const MIGRATIONS = {
    1: createMissingStores
  };

  let database = null;
  let opening = null;

  function friendlyError(message, original) {
    const error = new Error(message);
    error.cause = original || null;
    return error;
  }

  function open() {
    if (database) {
      return Promise.resolve(database);
    }

    if (opening) {
      return opening;
    }

    const attempt = new Promise(function (resolve, reject) {
      if (!window.indexedDB) {
        reject(friendlyError(
          "This browser does not support IndexedDB, so LifeOS cannot store data here."
        ));
        return;
      }

      let migrationError = null;
      let request;

      try {
        request = indexedDB.open(DB_NAME, DB_VERSION);
      } catch (error) {
        reject(friendlyError(
          "The database could not be opened: " + error.message,
          error
        ));
        return;
      }

      request.onupgradeneeded = function (event) {
        const db = request.result;
        const from = event.oldVersion;
        const to = event.newVersion || DB_VERSION;

        try {
          for (let version = from + 1; version <= to; version++) {
            if (MIGRATIONS[version]) {
              MIGRATIONS[version](db, request.transaction);
            }
          }
        } catch (error) {
          // Cancel the whole upgrade. The old data stays untouched.
          migrationError = error;
          try {
            request.transaction.abort();
          } catch (ignore) {}
        }
      };

      request.onsuccess = function () {
        const db = request.result;

        // Safety check: every collection we expect must exist.
        const missing = STORES.filter(function (name) {
          return !db.objectStoreNames.contains(name);
        });

        if (missing.length > 0) {
          db.close();
          reject(friendlyError(
            "The database is missing: " + missing.join(", ") +
            ". This usually means DB_VERSION in database.js needs to be " +
            "increased. Your saved data was not changed."
          ));
          return;
        }

        db.onversionchange = function () {
          db.close();
          database = null;
        };

        db.onclose = function () {
          database = null;
        };

        database = db;
        resolve(db);
      };

      request.onerror = function () {
        const original = request.error;

        if (migrationError) {
          reject(friendlyError(
            "A database upgrade failed and was cancelled. " +
            "Your saved data was not changed. (" +
            migrationError.message + ")",
            migrationError
          ));
          return;
        }

        if (original && original.name === "VersionError") {
          reject(friendlyError(
            "Your saved data was created by a newer version of LifeOS " +
            "than the code you are running. Nothing was changed. " +
            "Please use the newer code.",
            original
          ));
          return;
        }

        reject(friendlyError(
          (original && original.message) || "The database could not open.",
          original
        ));
      };

      request.onblocked = function () {
        // Another open LifeOS tab is using an older version.
        console.warn("LifeOS database upgrade is waiting for other tabs to close.");
      };
    });

    opening = attempt;

    attempt.then(
      function () { opening = null; },
      function () { opening = null; }
    );

    return attempt;
  }

  function getDatabase() {
    if (!database) {
      return Promise.reject(
        new Error("Database is not initialized.")
      );
    }

    return Promise.resolve(database);
  }

  function isOpen() {
    return database !== null;
  }

  window.LifeOSDB = {
    open,
    getDatabase,
    isOpen,
    stores: STORES.slice(),
    name: DB_NAME,
    version: DB_VERSION
  };

})();
