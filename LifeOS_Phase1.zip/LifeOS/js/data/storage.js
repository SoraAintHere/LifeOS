(function () {
  "use strict";

  function execute(storeName, mode, operation) {
    return window.LifeOSDB.getDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        let transaction;
        let request;
        let result;
        let requestError = null;

        try {
          transaction = db.transaction(storeName, mode);

          const store = transaction.objectStore(storeName);

          request = operation(store);

          request.onsuccess = function () {
            result = request.result;
          };

          request.onerror = function () {
            requestError = request.error;
          };

          transaction.oncomplete = function () {
            resolve(result);
          };

          transaction.onerror = function () {
            reject(
              requestError ||
              transaction.error ||
              new Error("Database operation failed.")
            );
          };

          transaction.onabort = function () {
            reject(
              requestError ||
              transaction.error ||
              new Error("Database operation was cancelled.")
            );
          };

        } catch (error) {
          reject(error);
        }
      });
    });
  }

  // Returns a rejected promise for an unknown collection, or null if fine.
  // (Rejecting, instead of throwing, lets callers always use .catch().)
  function checkStore(storeName) {
    if (window.LifeOSDB.stores.indexOf(storeName) === -1) {
      return Promise.reject(
        new Error("Unknown LifeOS storage collection: " + storeName)
      );
    }

    return null;
  }

  function checkRecord(data) {
    if (!data || !data.id) {
      return Promise.reject(
        new Error("A record must have an ID.")
      );
    }

    return null;
  }

  const storage = {

    // Adds a NEW record. Fails if a record with the same id exists.
    add: function (store, data) {
      const bad = checkStore(store) || checkRecord(data);
      if (bad) return bad;

      return execute(store, "readwrite", function (s) {
        return s.add(data);
      });
    },

    // Adds a record, or replaces the one with the same id.
    put: function (store, data) {
      const bad = checkStore(store) || checkRecord(data);
      if (bad) return bad;

      return execute(store, "readwrite", function (s) {
        return s.put(data);
      });
    },

    get: function (store, id) {
      const bad = checkStore(store);
      if (bad) return bad;

      return execute(store, "readonly", function (s) {
        return s.get(id);
      });
    },

    getAll: function (store) {
      const bad = checkStore(store);
      if (bad) return bad;

      return execute(store, "readonly", function (s) {
        return s.getAll();
      });
    },

    delete: function (store, id) {
      const bad = checkStore(store);
      if (bad) return bad;

      return execute(store, "readwrite", function (s) {
        return s.delete(id);
      });
    },

    // WARNING: removes EVERY record in a collection.
    // Never called by initialization, upgrades, or the self-test.
    clear: function (store) {
      const bad = checkStore(store);
      if (bad) return bad;

      return execute(store, "readwrite", function (s) {
        return s.clear();
      });
    },

    count: function (store) {
      const bad = checkStore(store);
      if (bad) return bad;

      return execute(store, "readonly", function (s) {
        return s.count();
      });
    }

  };

  window.LifeOSStorage = storage;

})();
