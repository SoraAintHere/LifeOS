(function () {
  "use strict";

  const app = document.getElementById("app");

  const pages = [
    { id: "dashboard", label: "Overview", icon: "⌂" },
    { id: "calendar", label: "Calendar", icon: "▦" },
    { id: "tasks", label: "Tasks", icon: "✓" },
    { id: "finance", label: "Finance", icon: "₱" },
    { id: "activity", label: "Activity", icon: "↗" },
    { id: "notes", label: "Knowledge Hub", icon: "▤" },
    { id: "goals", label: "Goals", icon: "◎" },
    { id: "reflection", label: "Reflection", icon: "✧" }
  ];

  const descriptions = {
    dashboard: "Your personal overview of everything that matters.",
    calendar: "Manage your schedule, events and reminders.",
    tasks: "Organize your responsibilities and daily tasks.",
    finance: "Keep track of your money and spending.",
    activity: "Monitor your movement and daily activity.",
    notes: "Your personal collection of knowledge and ideas.",
    goals: "Track your ambitions and personal progress.",
    reflection: "Review your days and record your thoughts."
  };

  const icons = {
    dashboard: "⌂",
    calendar: "▦",
    tasks: "✓",
    finance: "₱",
    activity: "↗",
    notes: "▤",
    goals: "◎",
    reflection: "✧"
  };

  let currentPage = "dashboard";
  const THEME_KEY = "lifeos-theme";

  function readSavedTheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      return saved === "light" || saved === "dark" ? saved : "dark";
    } catch (error) {
      return "dark";
    }
  }

  function saveTheme(value) {
    try {
      localStorage.setItem(THEME_KEY, value);
    } catch (error) {
      console.warn("LifeOS could not save the theme choice.", error);
    }
  }

  let theme = readSavedTheme();

  function applyTheme() {
    document.documentElement.setAttribute("data-theme", theme);
  }

  function storageCheckMarkup() {
    return window.LifeOSStorageCheckUI
      ? window.LifeOSStorageCheckUI.cardMarkup()
      : "";
  }

  function getDate() {
    return new Intl.DateTimeFormat("en-PH", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric"
    }).format(new Date());
  }

  function navigationMarkup(mobile = false) {
    const items = mobile
      ? pages.filter(page =>
          ["dashboard", "calendar", "tasks", "finance", "notes"].includes(page.id)
        )
      : pages;

    return items.map(page => `
      <button
        class="nav-item ${currentPage === page.id ? "active" : ""}"
        data-page="${page.id}"
        ${currentPage === page.id ? 'aria-current="page"' : ""}
      >
        <span class="nav-icon">${icons[page.id]}</span>
        <span>${page.label}</span>
      </button>
    `).join("");
  }

  function dashboardMarkup() {
    return `
      <div class="welcome-banner">
        <div class="eyebrow">YOUR PERSONAL WORKSPACE</div>
        <h2>Welcome to LifeOS.</h2>
        <p>
          Everything that matters, organized in one place.
          Take a moment to plan your day and stay on track.
        </p>
      </div>

      <div class="section-heading">
        <h3>Your overview</h3>
        <span>Today</span>
      </div>

      <div class="overview-grid">

        <article class="overview-card">
          <div class="card-top">
            <span class="card-label">Upcoming events</span>
            <span class="card-icon">▦</span>
          </div>
          <div class="card-value">0</div>
          <div class="card-description">No events scheduled</div>
        </article>

        <article class="overview-card">
          <div class="card-top">
            <span class="card-label">Pending tasks</span>
            <span class="card-icon">✓</span>
          </div>
          <div class="card-value">0</div>
          <div class="card-description">Nothing pending</div>
        </article>

        <article class="overview-card">
          <div class="card-top">
            <span class="card-label">Current balance</span>
            <span class="card-icon">₱</span>
          </div>
          <div class="card-value">₱0.00</div>
          <div class="card-description">No balance recorded</div>
        </article>

        <article class="overview-card">
          <div class="card-top">
            <span class="card-label">Daily activity</span>
            <span class="card-icon">↗</span>
          </div>
          <div class="card-value">0</div>
          <div class="card-description">Steps recorded</div>
        </article>

      </div>

      <div class="section-heading">
        <h3>Your day</h3>
        <span>Daily overview</span>
      </div>

      <div class="dashboard-grid">

        <section class="content-card">
          <h3>Upcoming events</h3>
          <div class="empty-state">
            <span class="empty-state-icon">▦</span>
            No upcoming events yet.<br>
            Your schedule will appear here.
          </div>
        </section>

        <section class="content-card">
          <h3>Tasks to complete</h3>
          <div class="empty-state">
            <span class="empty-state-icon">✓</span>
            You're all caught up.<br>
            Your pending tasks will appear here.
          </div>
        </section>

      </div>

      <div class="section-heading">
        <h3>System</h3>
        <span>Local storage</span>
      </div>

      ${storageCheckMarkup()}
    `;
  }

  function moduleMarkup(page) {
    return `
      <section class="module-placeholder">
        <span class="placeholder-icon">${icons[page.id]}</span>
        <h2>${page.label}</h2>
        <p>${descriptions[page.id]}</p>
        <p style="margin-top:12px">
          This module is not implemented yet.
        </p>
      </section>
    `;
  }

  function render() {
    applyTheme();

    const page = pages.find(item => item.id === currentPage);

    app.innerHTML = `
      <div class="app-layout">

        <aside class="sidebar">
          <div class="brand">Life<span>OS</span></div>

          <div class="nav-label">WORKSPACE</div>
          <nav class="nav-list">
            ${navigationMarkup()}
          </nav>

          <div class="sidebar-bottom">
            <button class="nav-item" data-theme-toggle>
              <span class="nav-icon">${theme === "dark" ? "☼" : "☾"}</span>
              <span>${theme === "dark" ? "Light appearance" : "Dark appearance"}</span>
            </button>
          </div>
        </aside>

        <main class="main-content">

          <header class="topbar">
            <div class="page-heading">
              <h1>${page.label}</h1>
              <p>${getDate()}</p>
            </div>

            <div class="topbar-actions">
              <button class="icon-button" data-theme-toggle
                aria-label="Toggle appearance">
                ${theme === "dark" ? "☼" : "☾"}
              </button>
            </div>
          </header>

          <div class="page-content">
            ${currentPage === "dashboard"
              ? dashboardMarkup()
              : moduleMarkup(page)}
          </div>

        </main>

        <nav class="mobile-nav">
          ${navigationMarkup(true)}
        </nav>

      </div>
    `;
  }

  function toggleTheme() {
    theme = theme === "dark" ? "light" : "dark";
    saveTheme(theme);
    render();
  }

  app.addEventListener("click", function (event) {
    const pageButton = event.target.closest("[data-page]");
    const themeButton = event.target.closest("[data-theme-toggle]");

    if (pageButton) {
      currentPage = pageButton.dataset.page;
      render();
      return;
    }

    if (themeButton) {
      toggleTheme();
    }
  });

  // app.js no longer starts itself. js/core/boot.js calls start()
  // once the database is open.
  function start() {
    render();
    console.log("LifeOS application shell initialized.");
  }

  window.LifeOSApp = {
    start: start,
    applyTheme: applyTheme
  };

})();
