(function () {
  "use strict";

  /*
    Storage check card (screen code only).
    All the real work happens in LifeOSSelfTest. This file just
    shows the button and the results.
  */

  const state = {
    status: "idle",   // idle | running | done
    report: null
  };

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function infoMarkup() {
    const boot = window.LifeOSBoot ? window.LifeOSBoot.getStatus() : null;

    if (!boot || !boot.database) {
      return "";
    }

    return `
      <p class="storage-meta">
        Database <strong>${escapeHtml(boot.database.name)}</strong>
        (version ${escapeHtml(boot.database.version)}) opened with
        ${boot.database.stores.length} collections.
      </p>
    `;
  }

  function resultMarkup() {
    const report = state.report;

    if (!report) {
      return "";
    }

    const steps = report.steps.map(function (step) {
      return `
        <li class="check-step ${step.ok ? "pass" : "fail"}">
          <span class="check-mark" aria-hidden="true">${step.ok ? "✓" : "✗"}</span>
          <span>
            ${escapeHtml(step.name)}
            ${step.detail
              ? `<span class="check-step-detail">${escapeHtml(step.detail)}</span>`
              : ""}
          </span>
        </li>
      `;
    }).join("");

    const title = report.ok
      ? "Storage is working. The test record was removed."
      : "The storage test found a problem.";

    const cleanup = report.cleanedUp
      ? ""
      : `<p class="storage-meta">The test record could not be removed. It is harmless and clearly marked (id starts with “__selftest__”). The next test will clean it up.</p>`;

    return `
      <div class="check-result ${report.ok ? "pass" : "fail"}"
           id="storage-check-result" tabindex="-1">
        <div class="check-title">${report.ok ? "✓" : "✗"} ${title}</div>
        <ol class="check-steps">${steps}</ol>
        ${cleanup}
      </div>
    `;
  }

  function bodyMarkup() {
    const running = state.status === "running";
    const label = running
      ? "Running test…"
      : (state.report ? "Run test again" : "Run storage self-test");

    return `
      ${infoMarkup()}
      <p class="storage-meta">
        Saves one temporary record, reads it back, then deletes it.
        Your real data is never changed.
      </p>
      <div role="status" aria-live="polite">
        ${resultMarkup()}
      </div>
      <div class="storage-actions">
        <button class="button" data-action="run-selftest"
          ${running ? "disabled aria-busy=\"true\"" : ""}>
          ${label}
        </button>
      </div>
    `;
  }

  function cardMarkup() {
    return `
      <section class="content-card storage-check" id="storage-check"
               aria-labelledby="storage-check-title">
        <h3 id="storage-check-title">Storage check</h3>
        <div id="storage-check-body">${bodyMarkup()}</div>
      </section>
    `;
  }

  function draw() {
    const body = document.getElementById("storage-check-body");
    if (body) {
      body.innerHTML = bodyMarkup();
    }
  }

  function run() {
    if (state.status === "running") {
      return;
    }

    if (!window.LifeOSSelfTest) {
      state.report = {
        ok: false,
        cleanedUp: true,
        steps: [{
          name: "Start the self-test",
          ok: false,
          detail: "js/services/storage-selftest.js did not load."
        }]
      };
      state.status = "done";
      draw();
      return;
    }

    state.status = "running";
    draw();

    window.LifeOSSelfTest.run().then(function (report) {
      state.report = report;
      state.status = "done";
      draw();

      const result = document.getElementById("storage-check-result");
      if (result) {
        result.focus();
      }
    });
  }

  document.addEventListener("click", function (event) {
    if (event.target.closest("[data-action='run-selftest']")) {
      run();
    }
  });

  window.LifeOSStorageCheckUI = {
    cardMarkup: cardMarkup,
    run: run
  };

})();
